var searchData=
[
  ['jump',['jump',['../structfat__boot.html#a83f9f2d1d0130f25f34c90dfc82e3751',1,'fat_boot::jump()'],['../structfat32__boot.html#a2d93fc193a64ecffbd71ead207fe4810',1,'fat32_boot::jump()']]]
];
